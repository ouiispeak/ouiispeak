export const A2Module1 = {
  level: 'A2',
  moduleNumber: 1,
  moduleSlug: 'a2-module-1',
  title: 'A2 · Module 1',
  description: 'Module en préparation.',
  lessons: [
    {
      lessonSlug: 'a2-module-1/lesson-1',
      file: './A2Module1Lesson1',
      title: 'Leçon 1',
    },
  ],
};
