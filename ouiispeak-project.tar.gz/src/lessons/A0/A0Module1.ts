export const A0Module1 = {
  level: 'A0',
  moduleNumber: 1,
  moduleSlug: 'a0-module-1',
  title: 'A0 · Module 1',
  description: 'Module en préparation.',
  lessons: [
    {
      lessonSlug: 'a0-module-1/lesson-1',
      file: './A0Module1Lesson1',
      title: 'Leçon 1',
    },
  ],
};
