export { lessonSlug, slides } from './slide-creator-model';

