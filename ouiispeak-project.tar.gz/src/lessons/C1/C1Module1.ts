export const C1Module1 = {
  level: 'C1',
  moduleNumber: 1,
  moduleSlug: 'c1-module-1',
  title: 'C1 · Module 1',
  description: 'Module en préparation.',
  lessons: [
    {
      lessonSlug: 'c1-module-1/lesson-1',
      file: './C1Module1Lesson1',
      title: 'Leçon 1',
    },
  ],
};
