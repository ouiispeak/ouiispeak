export const C2Module1 = {
  level: 'C2',
  moduleNumber: 1,
  moduleSlug: 'c2-module-1',
  title: 'C2 · Module 1',
  description: 'Module en préparation.',
  lessons: [
    {
      lessonSlug: 'c2-module-1/lesson-1',
      file: './C2Module1Lesson1',
      title: 'Leçon 1',
    },
  ],
};
