export const B1Module1 = {
  level: 'B1',
  moduleNumber: 1,
  moduleSlug: 'b1-module-1',
  title: 'B1 · Module 1',
  description: 'Module en préparation.',
  lessons: [
    {
      lessonSlug: 'b1-module-1/lesson-1',
      file: './B1Module1Lesson1',
      title: 'Leçon 1',
    },
  ],
};
