export const A1Module1 = {
  level: 'A1',
  moduleNumber: 1,
  moduleSlug: 'a1-module-1',
  title: 'A1 · Module 1',
  description: 'Module en préparation.',
  lessons: [
    {
      lessonSlug: 'a1-module-1/lesson-1',
      file: './A1Module1Lesson1',
      title: 'Leçon 1',
    },
  ],
};
