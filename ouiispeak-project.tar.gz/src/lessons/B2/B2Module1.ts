export const B2Module1 = {
  level: 'B2',
  moduleNumber: 1,
  moduleSlug: 'b2-module-1',
  title: 'B2 · Module 1',
  description: 'Module en préparation.',
  lessons: [
    {
      lessonSlug: 'b2-module-1/lesson-1',
      file: './B2Module1Lesson1',
      title: 'Leçon 1',
    },
  ],
};
