export { default } from './AISpeakStudentRepeatSlide';
