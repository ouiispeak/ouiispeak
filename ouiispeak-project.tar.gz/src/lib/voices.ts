export type SupportedLang = 'fr' | 'en';

export const DEFAULT_SPEECH_LANG: SupportedLang = 'fr';
