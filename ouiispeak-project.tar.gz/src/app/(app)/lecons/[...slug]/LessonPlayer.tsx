export { default } from '@/components/lesson/LessonPlayer';
export * from '@/components/lesson/LessonPlayer';