// Minimal group layout – no header here
export default function AppGroupLayout({ children }: { children: React.ReactNode }) {
  return <>{children}</>;
}
