import type { Metadata } from 'next';
export const metadata: Metadata = { title: 'Carnet — OuiiSpeak' };

export default function CarnetPage() {
  return (
    <main>
      <h1>Carnet</h1>
    </main>
  );
}

