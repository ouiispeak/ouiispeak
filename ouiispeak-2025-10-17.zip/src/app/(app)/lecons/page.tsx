import type { Metadata } from 'next';
export const metadata: Metadata = { title: 'Leçons — OuiiSpeak' };

export default function LeconsPage() {
  return (
    <main>
      <h1>Leçons</h1>
    </main>
  );
}

