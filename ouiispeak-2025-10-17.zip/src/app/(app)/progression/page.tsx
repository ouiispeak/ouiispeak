import type { Metadata } from 'next';
export const metadata: Metadata = { title: 'Progression — OuiiSpeak' };

export default function ProgressionPage() {
  return (
    <main>
      <h1>Progression</h1>
    </main>
  );
}

