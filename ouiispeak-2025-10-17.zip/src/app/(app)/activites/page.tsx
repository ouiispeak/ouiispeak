import type { Metadata } from 'next';
export const metadata: Metadata = { title: 'Activités — OuiiSpeak' };

export default function ActivitesPage() {
  return (
    <main>
      <h1>Activités</h1>
    </main>
  );
}

